# MI-diving
Remake of qbus diving

This is the first version of this script
if you have any issues please dm me on discord - ilAn#9613

```
-------------------------------------------------
* Boat shop where you can buy boats
* Boat garage where you can store your boats
* Diving places where you can collect corals
-------------------------------------------------
Requirements
MI-Progressbar - https://github.com/i1An/MI-Progressbar
-------------------------------------------------
